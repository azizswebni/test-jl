from flask import Flask, jsonify, request
from flask_restful import Api, Resource
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
from bson.objectid import ObjectId
import os

# Load environment variables from .env
load_dotenv()

# Initialize Flask app
app = Flask(__name__)

# Enable CORS
CORS(app, supports_credentials=True)

# Set up API
api = Api(app)

# JWT Configuration
app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY", "super-secret-key")
jwt = JWTManager(app)

# MongoDB Connection Setup
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/mydatabase")
client = MongoClient(MONGO_URI)
db = client.get_database()
users_collection = db["users"]  # Store users in the 'users' collection
hotels_collection = db["hotels"]  # Example hotels collection
mails_collection  = db["mail"] 
reservations_collection = db["reservations"]

def insert_hotels_if_empty():
    from consts.consts import hotels_data
    """Check if 'hotels' collection is empty and insert data if needed."""
    if hotels_collection.count_documents({}) == 0:
        hotels_collection.insert_many(hotels_data)
        print("Hotels data inserted into the database.")
    else:
        print("Hotels collection already populated.")


with app.app_context():
    """Ensure the database is set up before the first request."""
    insert_hotels_if_empty()

# User Registration Route
class Register(Resource):
    def post(self):
        data = request.get_json()
        email = data.get("email")
        password = data.get("password")

        if users_collection.find_one({"email": email}):
            return {"message": "User with this email already exists."}, 400

        hashed_password = generate_password_hash(password)
        users_collection.insert_one({"email": email, "password": hashed_password})
        return {"message": "User registered successfully."}, 201

# User Login Route (JWT Generation)
class Login(Resource):
    def post(self):
        data = request.get_json()
        email = data.get("email")
        password = data.get("password")

        user = users_collection.find_one({"email": email})
        if not user or not check_password_hash(user["password"], password):
            return {"message": "Invalid credentials."}, 401

        # Generate JWT Token
        access_token = create_access_token(identity=email)
        return {"access_token": access_token}, 200

class SendMails(Resource):
    @jwt_required()
    def post(self):
        data = request.get_json()
        from mailersend import emails

        mailer = emails.NewEmail(os.getenv('MAILERSEND_API_KEY'))

        subject = data.get('subject')
        text = data.get('text')
        recipient = data.get('recipient')

        my_mail = "info@trial-351ndgwev1xgzqx8.mlsender.net"
        subscriber_list = [recipient ,'jlayel2019@gmail.com']

        response_subject = "Thank You for Reaching Out! (Annatator App)"
        response_text = """Hey ,

        Thank you for contacting us through the contact section of our website. We have received your message and appreciate you taking the time to get in touch with us.

        Our team is reviewing your inquiry, and we will follow up with you shortly regarding the subject you shared. If you have any additional details or questions in the meantime, please feel free to reply to this email.

        We appreciate your patience and look forward to assisting you further.

        Best regards,"""

        mailer.send(my_mail, subscriber_list, response_subject, response_text)

        mails_collection.insert_one({"email": recipient, "subject":subject, "content": text})

        return {"message":"ok"}, 200

# Resource to get all hotels
class Hotels(Resource):
    def get(self):
        # Retrieve all hotel documents from MongoDB and convert them to a list of dictionaries
        hotels = list(hotels_collection.find({}, {"_id": 0}))  # Exclude _id field from response
        return {"hotels": hotels}, 200  # Return data with 200 OK status


class Reservation(Resource):
    def put(self):
        data = request.get_json()
        
        # Validate input data
        reservation_id = data.get('id')
        new_status = data.get('reservation_status')
        
        if not reservation_id or not new_status:
            return {"message": "Missing required fields."}, 400

        # Find the reservation by ID
        reservation = reservations_collection.find_one({"_id": ObjectId(reservation_id)})

        if not reservation:
            return {"message": "Reservation not found."}, 404

        # Update the reservation status
        reservations_collection.update_one(
            {"_id": ObjectId(reservation_id)},
            {"$set": {"reservation_status": new_status}}
        )

        return {"message": "Reservation status updated successfully."}, 200


    def post(self):
        data = request.get_json()

        # List of all required fields
        required_fields = [
            "name_user", "email", "Nombre de chambre", "Adultes", 
            "Nuits", "Nombre d'Enfants",
            "num_phone",
            "date_reservation"
        ]

        # Check if any required field is missing
        for field in required_fields:
            if field not in data:
                missed = field.replace("_"," ")
                return {
                        "message": f"Missing required {missed}"
                    }, 400 
            

        # Extract reservation data
        name_user = data["name_user"]
        email = data["email"]
        nombre_de_chambre = data["Nombre de chambre"]
        nombre_adultes = data["Adultes"]
        nombre_nuits = data["Nuits"]
        nombre_enfants = data["Nombre d'Enfants"]
        num_phone = data["num_phone"]
        hotel_id = data["hotel_id"]
        hotel = hotels_collection.find_one({"id": hotel_id})
        price = hotel["price"]
        date_reservation = data["date_reservation"]
        from datetime import datetime
        # Create the reservation document
        reservation = {
            "hotel_id":hotel_id,
            "name_user": name_user,
            "email": email,
            "Nombre de chambre": nombre_de_chambre,
            "Adultes": nombre_adultes,
            "Nuits": nombre_nuits,
            "Nombre d'Enfants": nombre_enfants,
            "Total": price * int(nombre_nuits),
            "num_phone": num_phone,
            "reservation_status": "Pending",
            "created_at": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
            "date_reservation": date_reservation
        }

        # Insert into MongoDB
        reservations_collection.insert_one(reservation)

        return {"message": "Reservation added successfully."}, 201
    def get(self):
        # Get email from query parameters
        email = request.args.get("email")

        # Validate if email is provided
        if email:
            # Query the reservations collection for the provided email
            reservations = list(reservations_collection.find({"email": email}))
        else:
            reservations = list(reservations_collection.find({}))

        # Transform MongoDB ObjectId to string and prepare the response
        for reservation in reservations:
            hotel = hotels_collection.find_one({"id": reservation["hotel_id"]})
            reservation["_id"] = str(reservation["_id"])
            hotel.pop('_id')
            reservation["hotel"] = hotel

        return {"reservations": reservations}, 200


# Add API Routes
api.add_resource(Register, "/register")
api.add_resource(Login, "/login")
api.add_resource(SendMails, "/send_mail")
api.add_resource(Hotels, "/hotels")
api.add_resource(Reservation, "/reservation")

# Main entry point
if __name__ == "__main__":
    port = int(os.getenv("DEFAULT_PORT", 81))
    app.run(host="0.0.0.0", port=port, debug=True)
