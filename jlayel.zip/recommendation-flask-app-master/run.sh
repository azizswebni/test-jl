sudo docker-compose down --remove-orphans
sudo docker-compose up --build -d