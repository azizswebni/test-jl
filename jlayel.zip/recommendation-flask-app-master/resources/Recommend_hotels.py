from flask import jsonify, request
from flask_restful import Api, Resource
import json
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd
from googlesearch import search
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity

# Charger les données
data = pd.read_csv("test.csv")

# Créer une classe pour la recommandation d'hôtels


class RecommendHotels(Resource):
    @jwt_required()
    def post(self):
        def recommend_hotel_site(hotel):
            search_query = f"hotel  {hotel} online"
            search_results = list(search(search_query,num_results=1))

            if search_results:
                recommended_site = search_results[0]
                return recommended_site
            else:
                return None
        # Récupérer les données postées
        posted_data = request.get_json()
        original_object = posted_data["user_choices"]
        user_choices = {
        'Ville': original_object['city']['value'].strip(),  # Extracting and stripping whitespace from the city value
        'Adultes': original_object['adult']['value'],
        'Nombre d\'Enfants': original_object['enfants']['value'],
        'Nuits': original_object['nuits']['value'],
        'Etoiles': original_object['etoiles']['value'],
        'Rooms number': original_object['rooms']['value'] }
        top_n = 3
        # Convertir les choix de l'utilisateur en un DataFrame
        user_df = pd.DataFrame([user_choices])
        print(user_df)

        # Ajouter une colonne d'ID temporaire
        user_df['ID'] = 'user_input'

        # Concaténer les données utilisateur et les données d'hôtel
        combined_data = pd.concat([data, user_df], ignore_index=True)
        print(combined_data)
        # Vectorisation des caractéristiques
        tfidf_vectorizer =TfidfVectorizer()
        tfidf_matrix = tfidf_vectorizer.fit_transform(combined_data[['Ville', 'Adultes', 'Nombre d\'Enfants','Nuits', 'Etoiles', 'Rooms number','Description']].astype(str).apply(' '.join, axis=1))

        # Calcul de la similarité cosinus entre les hôtels
        cosine_similarities = cosine_similarity(tfidf_matrix)

        # Index de l'entrée utilisateur
        user_index = combined_data[combined_data['ID'] == 'user_input'].index[0]

        # Calcul des similarités entre l'entrée utilisateur et les hôtels
        similarities_with_user = cosine_similarities[user_index]

        # Trier les hôtels par similarité décroissante
        similar_hotel_indices = similarities_with_user.argsort()[::-1][1:]

        # Récupérer les noms des hôtels recommandés sans doublons
        recommended_hotel_names = []
        for index in similar_hotel_indices:
            hotel_name = data.iloc[index]['Description']
            if hotel_name not in recommended_hotel_names:
                recommended_hotel_names.append(hotel_name)
                if len(recommended_hotel_names) == top_n:
                    break
        print(recommended_hotel_names)
        recommended_hotels_sites = [recommend_hotel_site(hotels) for hotels in recommended_hotel_names]
        # Create a list of dictionaries
        hotel_data = []
        for hotel, link in zip(recommended_hotel_names, recommended_hotels_sites):
            if link:
                hotel_data.append({"hotel_name": hotel, "link": link})
            else:
                hotel_data.append({"hotel_name": hotel, "link": "No recommendations found for {}".format(hotel)})

        print(recommended_hotels_sites)
        return jsonify({"recommended_hotels": hotel_data})
