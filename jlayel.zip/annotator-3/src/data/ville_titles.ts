const ville_titles = [
  { value: " Hammamet", id: "Hammamet" },
  { value: "Sousse ", id: " Sousse" },
  {
    value: "Monastir",
    id: "Monastir",
  },
  { value: "Tabarka", id: "Tabarka" },
  {
    value: "Mahdia",
    id: "Mahdia",
  },
  {
    value: "Djerba",
    id: "Djerba",
  },
  {
    value: "Paris",
    id: "Paris",
  },
  {
    value: "Tozeur",
    id: "Tozeur",
  },
  { value: "Korba", id: "Korba" },
  {
    value: "Zarzis",
    id: " Zarzis",
  },
  {
    value: "Istanbul",
    id: "Istanbul",
  },
  { value: "Kairouan", id: "Kairouan" },
  { value: "Korbous", id: "Korbous" },
  { value: "Douz", id: "Douz" },
];

export default ville_titles;
