import { Hotel } from "@/components/hotels/hotels";

export const promo_hotels: Hotel[] = [
  {
    id: 1,
    name: "Eden Yasmine Resort & Spa",
    location: "Hammamet",
    rating: 4,
    price: 114, // in TND per person per night
    image: "https://image.resabooking.com/images/image_panoramique/Eden_Yasmine_Resort_Meeting_&_Spa_2.jpg",
  },
  {
    id: 2,
    name: "Bel Azur Thalasso & Bungalows",
    location: "Hammamet",
    rating: 4.5,
    price: 90, // in TND per person per night
    image: "https://image.resabooking.com/images/image_panoramique/Bel_Azur_Thalasso_&_Bungalows_2.jpg",
  },
  {
    id: 3,
    name: "Jaz Tour Khalef",
    location: "Sousse",
    rating: 4.5,
    price: 132, // in TND per person per night
    image: "https://image.resabooking.com/images/image_panoramique/Jaz_Tour_Khalef_2.jpg",
  },
  {
    id: 4,
    name: "Skanes Serail & Aquapark",
    location: "Monastir",
    rating: 3.5,
    price: 200, // indicative example
    image: "https://image.resabooking.com/images/image_panoramique/Skanes_Serail_&_Aquapark_2.jpg",
  },
  {
    id: 5,
    name: "Vincci Helios Beach",
    location: "Djerba",
    rating: 4.5,
    price: 150, // in TND per person per night
    image: "https://image.resabooking.com/images/image_panoramique/Vincci_Helios_Beach_2.jpg",
  }, {
    id: 5,
    name: "Vincci Safira Palms",
    location: "Djerba",
    rating: 4,
    price: 150, // in TND per person per night
    image: "https://image.resabooking.com/images/image_panoramique/Vincci_Safira_Palms_2.jpg",
  },
];
