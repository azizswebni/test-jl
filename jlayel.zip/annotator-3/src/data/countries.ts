const countries = [
  { value: "hammamet", label: "hammamet",id:1 },
  { value: "sousse", label: "sousse",id:2 },
  { value: "mahdia", label: "mahdia",id:3 },
  { value: "monastir", label: "monastir",id:4 },
  { value: "djerba", label: "djerba",id:5 },
  { value: "tozeur", label: "tozeur",id:6 },
];

export { countries };
