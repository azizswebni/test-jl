import axios, { AxiosError } from "axios";

interface GetReservationsResponse {
  reservations: any[];
}

// Function to fetch reservations
const getReservationsApi = async (
  accessToken: string,
  email: string | null
): Promise<any[] | undefined> => {
  try {
    // Access the API URL from environment variables
    const apiUrl = import.meta.env.VITE_API_URL;

    // Make a GET request to the reservations endpoint with the authorization header
    let url: string = "";
    if (email) {
      url = `${apiUrl}/reservation?email=${email}`;
    } else {
      url = `${apiUrl}/reservation`;
    }
    const response = await axios.get<GetReservationsResponse>(url, {
      headers: {
        Authorization: `Bearer ${accessToken}`, // Include the access token for authorization
      },
    });

    // Access the reservations from the response
    const reservations = response.data.reservations;

    return reservations; // Return the reservations for further use
  } catch (error) {
    // Handle error appropriately
    const axiosError = error as AxiosError; // Cast error to AxiosError for better typing
    if (axiosError.response) {
      // The request was made and the server responded with a status code
      console.error("Error response:", axiosError.response.data);
      console.error("Error status:", axiosError.response.status);
    } else if (axiosError.request) {
      // The request was made but no response was received
      console.error("Error request:", axiosError.request);
    } else {
      // Something happened in setting up the request
      console.error("Error message:", axiosError.message);
    }
  }
};
interface CreateReservationResponse {
  message: string;
}
const createReservationApi = async (
  reservationData: any
): Promise<any | undefined> => {
  try {
    // Access the API URL from environment variables
    const apiUrl = import.meta.env.VITE_API_URL;

    // Make a POST request to the reservations endpoint with the reservation data
    const response = await axios.post<CreateReservationResponse>(
      `${apiUrl}/reservation`,
      reservationData
    );

    // Access the created reservation from the response
    const createdReservation = response.data.message;

    return createdReservation; // Return the created reservation for further use
  } catch (error) {
    throw error;
  }
};

const updateReservationApi = async (
  updateReservation: any
): Promise<any | undefined> => {
  try {
    // Access the API URL from environment variables
    const apiUrl = import.meta.env.VITE_API_URL;

    // Make a POST request to the reservations endpoint with the reservation data
    const response = await axios.put<CreateReservationResponse>(
      `${apiUrl}/reservation`,
      updateReservation
    );

    // Access the created reservation from the response
    const updateReservationResponse = response.data.message;

    return updateReservationResponse; // Return the created reservation for further use
  } catch (error) {
    throw error;
  }
};

export { getReservationsApi, createReservationApi,updateReservationApi };
