import axios, { AxiosError } from "axios";

const loginApi = async (
  email: string,
  password: string
): Promise<string | undefined> => {
  try {
    // Access the API URL from environment variables
    const apiUrl = import.meta.env.VITE_API_URL;

    // Make a POST request to the login endpoint
    const response = await axios.post(`${apiUrl}/login`, {
      email,
      password,
    });

    // Access the token from the response
    const accessToken = response.data.access_token;

    return accessToken; // You can return the token for further use
  } catch (error) {
    // Handle error appropriately
    const axiosError = error as AxiosError; // Cast error to AxiosError for better typing
    if (axiosError.response) {
      // The request was made and the server responded with a status code
      console.error("Error response:", axiosError.response.data);
      console.error("Error status:", axiosError.response.status);
    } else if (axiosError.request) {
      // The request was made but no response was received
      console.error("Error request:", axiosError.request);
    } else {
      // Something happened in setting up the request
      console.error("Error message:", axiosError.message);
    }
  }
};
interface RegisterResponse {
  message: string;
}

// Define the function with types for email and password parameters
const registerApi = async (
  email: string,
  password: string
): Promise<string | undefined> => {
  try {
    // Access the API URL from environment variables
    const apiUrl = import.meta.env.VITE_API_URL;

    // Make a POST request to the register endpoint
    const response = await axios.post<RegisterResponse>(`${apiUrl}/register`, {
      email,
      password,
    });

    // Access the message from the response
    const message = response.data.message;

    return message; // Return the message for further use
  } catch (error) {
    // Handle error appropriately
    const axiosError = error as AxiosError; // Cast error to AxiosError for better typing
    if (axiosError.response) {
      // The request was made and the server responded with a status code
      console.error("Error response:", axiosError.response.data);
      console.error("Error status:", axiosError.response.status);
    } else if (axiosError.request) {
      // The request was made but no response was received
      console.error("Error request:", axiosError.request);
    } else {
      // Something happened in setting up the request
      console.error("Error message:", axiosError.message);
    }
  }
};
export { loginApi, registerApi };
