import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Star, MapPin } from "lucide-react";
import { Link } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "../ui/toaster";

export interface Hotel {
  id: number;
  name: string;
  location: string;
  rating: number;
  price: number;
  image: string;
}

interface HotelCardsProps {
  hotels: Hotel[];
  title: String;
  currency: String;
  add_reservation: (hotel_data: any) => void;
}

export default function HotelCards({
  hotels,
  title,
  currency,
  add_reservation,
}: HotelCardsProps) {
  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold mb-6 text-center">{title}</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {hotels.map((hotel) => (
          <Card key={hotel.id} className="overflow-hidden">
            <CardHeader className="p-0">
              <img
                src={hotel.image}
                alt={hotel.name}
                width={300}
                height={200}
                className="w-full h-48 object-cover"
              />
            </CardHeader>
            <CardContent className="p-4">
              <CardTitle className="text-xl mb-2">{hotel.name}</CardTitle>
              <div className="flex items-center mb-2">
                <MapPin className="w-4 h-4 mr-1 text-gray-500" />
                <span className="text-sm text-gray-600">{hotel.location}</span>
              </div>
              <div className="flex items-center mb-2">
                <Star className="w-4 h-4 mr-1 text-yellow-500" />
                <span className="text-sm font-semibold">{hotel.rating}</span>
                <span className="text-sm text-gray-600 ml-1">/ 5</span>
              </div>
              <div className="text-lg font-bold text-primary">
                {hotel.price} {currency}
                <span className="text-sm font-normal text-gray-600">
                  per night
                </span>
              </div>
            </CardContent>
            <CardFooter className="p-4 pt-0">
              <Button className="w-full" onClick={() => add_reservation(hotel)}>
                Add reservation
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      <Toaster />
    </div>
  );
}
