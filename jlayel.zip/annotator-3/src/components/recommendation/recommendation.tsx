import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import adultes_nbr from "@/data/adultes";
import { Button } from "../ui/button";
import { enfants_nbr, etoiles_nbr, nuits_nbr } from "@/data/data";
import { countries } from "@/data/countries";
import HotelCards, { Hotel } from "../hotels/hotels";
import { useRef, useState } from "react";
import { hotels } from "@/data/hotels";
import { ResetIcon } from "@radix-ui/react-icons";
import { useNavigate } from "react-router-dom";
import { useReservationStore } from "@/store/reservationStore";

export const options = [
  {
    name: "Ville",
    options: countries,
  },
  {
    name: "Nombre de chambre",
    options: adultes_nbr,
  },
  {
    name: "Etoiles",
    options: etoiles_nbr,
  },
  {
    name: "Adultes",
    options: adultes_nbr,
  },
  {
    name: "Nuits",
    options: nuits_nbr,
  },
  {
    name: "Nombre d'Enfants",
    options: enfants_nbr,
  },
];

function Recommendation() {
  const { set_reservation_data } = useReservationStore();
  const hotelsRef = useRef<HTMLDivElement | null>(null);
  const [hotelsData, setHotelsData] = useState(hotels);
  const [selectedVille, setSelectedVille] = useState<any>(null);
  const [search, setSearch] = useState(false);
  const [selectedStars, setSelectedStars] = useState<any>(null);
  const [addiotionalData, setAdditionalData] = useState<any>({});
  const navigate = useNavigate();
  return (
    <>
      <div className="bg-hero bg-cover bg-no-repeat h-svh flex flex-col justify-center items-center">
        <div className="flex flex-col w-5/6 items-center justify-center gap-5">
          <div className="rounded-xl bg-white bg-opacity-98 p-10 w-5/6 flex flex-row justify-start items-center flex-wrap gap-20">
            <div className="w-5/6 text-black mb-5">
              <h1 className="scroll-m-20 text-4xl font-extrabold tracking-tight lg:text-5xl">
                Réservez votre hôtel
              </h1>
              <p className="leading-7 [&:not(:first-child)]:mt-6">
                Découvrez une nouvelle façon de trouver votre hébergement idéal
                avec notre plateforme de recommandation d'hôtels. Parcourez
                notre sélection minutieusement choisie, basée sur vos
                préférences personnelles, et préparez-vous à vivre des séjours
                inoubliables, où chaque nuit est aussi confortable
                qu'exceptionnelle.
              </p>
            </div>
            {options.map((opt, idx) => {
              return (
                <div className="w-1/4">
                  <Select
                    key={idx}
                    onValueChange={(e) => {
                      switch (opt.name) {
                        case "Ville":
                          setSelectedVille(e);
                          break;
                        case "Etoiles":
                          setSelectedStars(parseInt(e));
                          break;
                        default:
                          setAdditionalData((prev: any) => {
                            return { ...prev, [opt.name]: e };
                          });
                          break;
                      }
                    }}
                  >
                    {opt.name}
                    <SelectTrigger>
                      <SelectValue placeholder={opt.name} />
                    </SelectTrigger>
                    <SelectContent>
                      {opt.options.map((o, idx) => (
                        <SelectItem key={idx} value={`${o.value}`}>
                          {o.value}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              );
            })}
          </div>
          <div className="flex justify-center items-center w-full gap-2">
            {search && (
              <Button
                onClick={() => {
                  setSelectedVille(null);
                  setSelectedStars(null);
                  setSearch(false);
                  setHotelsData(hotels);
                }}
              >
                <ResetIcon />
              </Button>
            )}
            <Button
              size={"lg"}
              variant={"outline"}
              onClick={() => {
                if (hotelsRef.current) {
                  setSearch(true);
                  setHotelsData(
                    hotels.filter(
                      (hotel: Hotel) =>
                        (selectedStars
                          ? hotel.rating <= selectedStars
                          : true) &&
                        (selectedVille
                          ? hotel.location.toLowerCase() ===
                            selectedVille.toLowerCase()
                          : true)
                    )
                  );
                  window.scrollTo({
                    top: hotelsRef.current.offsetTop,
                    left: 0,
                    behavior: "smooth",
                  });
                }
              }}
            >
              {" "}
              Search
            </Button>
          </div>
        </div>
      </div>
      <div ref={hotelsRef}>
        <HotelCards
          hotels={hotelsData}
          title="Hotels"
          currency=" DT"
          add_reservation={(selected_hotel) => {
            window.scrollTo({
              top: 0,
              left: 0,
              behavior: "smooth",
            });
            set_reservation_data({
              hotel: selected_hotel,
              additional_data: addiotionalData,
            });
            navigate("/reservation");
          }}
        />
        {hotelsData.length == 0 && (
          <div
            id="no-hotels"
            className="flex items-center justify-center pb-10"
          >
            <div className="text-center">
              <img
                src="https://cdn-icons-png.flaticon.com/512/4076/4076549.png"
                alt="No results"
                className="w-32 h-15 mx-auto mb-4 opacity-70"
              />
              <h2 className="text-2xl font-semibold text-gray-700">
                No Hotels Found
              </h2>
              <p className="text-gray-500 mt-2">
                Try adjusting your search criteria.
              </p>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

export default Recommendation;
