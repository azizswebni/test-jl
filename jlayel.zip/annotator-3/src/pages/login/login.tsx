/**
 * v0 by Vercel.
 * @see https://v0.dev/t/1ADs2FRNaQg
 * Documentation: https://v0.dev/docs#integrating-generated-code-into-your-nextjs-app
 */
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useAuthStore } from "@/store/authStore";
import { useNavigate } from "react-router-dom";
import { loginApi } from "@/services/login";
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "@/components/ui/toaster";
import { useState } from "react";
export default function Login() {
  const { set_auth_token,set_email } = useAuthStore();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { toast } = useToast();
  const login = async () => {
    try {
      if (!email || !password) {
        toast({
          variant: "destructive",
          title: "Login failed.",
          description: "Email and password are required.",
        });
        return; // Exit early if validation fails
      }
      // Call the login API function with email and password
      const auth_token = await loginApi(email, password);
      // Check if the token is valid before proceeding
      if (auth_token) {
        set_auth_token(auth_token); // Set the auth token in the state
        set_email(email)
        navigate("/"); // Navigate to the home page or desired route
      } else {
        toast({
          variant: "destructive",
          title: "Login failed. ",
          description: "Please check your credentials.",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Login failed. ",
        description: "Please check your credentials.",
      });
    }
  };
  return (
    <div className="flex justify-center items-center h-screen w-full">
      <Card className="mx-auto max-w-sm">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold">Login</CardTitle>
          <CardDescription>
            Enter your email and password to login to your account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="m@example.com"
                value={email} // Bind email state
                onChange={(e) => setEmail(e.target.value)} // Update email state
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                required
                value={password} // Bind password state
                onChange={(e) => setPassword(e.target.value)} // Update password state
              />
            </div>
            <Button type="submit" className="w-full" onClick={login}>
              Login
            </Button>
          </div>
        </CardContent>
      </Card>
      <Toaster />
    </div>
  );
}
