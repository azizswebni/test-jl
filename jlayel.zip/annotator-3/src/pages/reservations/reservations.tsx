import { options } from "@/components/recommendation/recommendation";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useReservationStore } from "@/store/reservationStore";
import { useEffect, useRef, useState } from "react";
import { Input } from "@/components/ui/input";
import {
  createReservationApi,
  getReservationsApi,
} from "@/services/reservations";
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "@/components/ui/toaster";
import { useAuthStore } from "@/store/authStore";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Link, useNavigate } from "react-router-dom";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";

function Reservations() {
  const { reservation_data, set_reservation_data } = useReservationStore();
  const { email, auth_token } = useAuthStore();
  const reservationssRef = useRef<HTMLDivElement | null>(null);
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(
    new Date()
  );
  const [reservations, setReservations] = useState<any>([]);
  const [addiotionalData, setAdditionalData] = useState<any>(
    reservation_data ? reservation_data.additional_data : null
  );
  useEffect(() => {
    const getReservations = async () => {
      const result = await getReservationsApi(auth_token || "", email);
      setReservations(result || []);
    };
    getReservations();
    if (reservation_data == null) {
      if (reservationssRef.current)
        window.scrollTo({
          top: reservationssRef.current.offsetTop,
          left: 0,
          behavior: "smooth",
        });
    }
  }, []);
  const navigate = useNavigate();

  const filtered_options = options.filter(
    (option: any) => !["Etoiles", "Ville"].includes(option.name)
  );
  const confirmBooking = async () => {
    try {
      const reservation_response = await createReservationApi({
        ...addiotionalData,
        email: email,
        hotel_id: reservation_data.hotel.id,
      });
      if (reservation_response) {
        toast({
          title: reservation_response,
        });
        setTimeout(() => {
          set_reservation_data(null);
          setAdditionalData(null);
          navigate(0);
        }, 1000);
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Attention",
        description: error.response.data.message,
      });
    }
  };
  return (
    <>
      <div className="bg-hero bg-cover bg-no-repeat h-svh flex flex-col justify-center items-center">
        <div className="flex flex-col w-5/6 items-center justify-center gap-5">
          <div className="rounded-xl bg-white p-10 w-5/6 flex flex-row justify-center items-center flex-wrap gap-20">
            {reservation_data != null ? (
              <>
                <img
                  src={reservation_data.hotel.image}
                  alt={reservation_data.hotel.name}
                  className="w-1/3 rounded-xl"
                />
                <section className="bg-white dark:bg-gray-900">
                  <div className="py-8 lg:py-16 px-4 mx-auto max-w-screen-md">
                    <h2 className="mb-4 text-4xl tracking-tight font-extrabold text-center text-gray-900 dark:text-white">
                      Hotel: {reservation_data.hotel.name}
                    </h2>
                    <form action="#" className="space-y-8">
                      <div className="w-full space-y-8">
                        <div>
                          <h1>Date de reservation</h1>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Input
                                placeholder="Pick a date"
                                value={selectedDate ? format(selectedDate, "PPP") : ""}
                                readOnly
                                className="cursor-pointer"
                              />
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-2">
                              <Calendar
                                mode="single"
                                selected={selectedDate}
                                onSelect={(e)=>{
                                  setAdditionalData((prev: any) => {
                                    return {
                                      ...prev,
                                      ["date_reservation"]: e,
                                    };
                                  });
                                  setSelectedDate(e)
                                }}
                              />
                            </PopoverContent>
                          </Popover>
                        </div>
                        <div>
                          <h1>Nom adherent</h1>
                          <Input
                            type="name"
                            placeholder="name"
                            value={addiotionalData["name_user"]}
                            onChange={(e) => {
                              setAdditionalData((prev: any) => {
                                return {
                                  ...prev,
                                  ["name_user"]: e.target.value,
                                };
                              });
                            }}
                          />
                        </div>
                        <div>
                          <h1>Num téléphone</h1>
                          <PhoneInput
                            country={"tn"}
                            onlyCountries={["tn"]}
                            disableSearchIcon={true}
                            inputProps={{
                              name: "phone",
                              required: true,
                              autoFocus: true,
                            }}
                            inputStyle={{ width: "100%" }}
                            value={addiotionalData["num_phone"]}
                            onChange={(e) => {
                              setAdditionalData((prev: any) => {
                                return { ...prev, ["num_phone"]: e };
                              });
                            }}
                          />
                        </div>
                      </div>
                      {filtered_options.map((opt, idx) => {
                        return (
                          <div>
                            <Select
                              key={idx}
                              onValueChange={(e) => {
                                setAdditionalData((prev: any) => {
                                  return { ...prev, [opt.name]: e };
                                });
                              }}
                              value={addiotionalData[opt.name] || null}
                            >
                              {opt.name}
                              <SelectTrigger>
                                <SelectValue placeholder={opt.name} />
                              </SelectTrigger>
                              <SelectContent>
                                {opt.options.map((o, idx) => (
                                  <SelectItem key={idx} value={`${o.value}`}>
                                    {o.value}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        );
                      })}
                      <div>
                        {addiotionalData["Nuits"] &&
                          reservation_data.hotel.price && (
                            <h1 className="mb-4 text-2xl tracking-tight font-extrabold text-gray-900 dark:text-white">
                              Total{" "}
                              {reservation_data.hotel.price *
                                parseInt(addiotionalData["Nuits"])}{" "}
                              DT
                            </h1>
                          )}
                      </div>

                    </form>
                    <Button
                      variant={"outline"}
                      className="py-3 px-5 text-sm font-medium text-center text-black rounded-xl bg-green-500 sm:w-fit hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800"
                      onClick={confirmBooking}
                    >
                      Confirm Booking
                    </Button>
                  </div>
                </section>
              </>
            ) : (
              <div
                id="no-hotels"
                className="flex items-center justify-center pb-10"
              >
                <div className="text-center gap-2">
                  <img
                    src="https://cdn-icons-png.flaticon.com/512/4076/4076549.png"
                    alt="No results"
                    className="w-32 h-15 mx-auto mb-4 opacity-70"
                  />
                  <h2 className="text-2xl font-semibold text-gray-700">
                    No Booking in progress
                  </h2>
                  <p className="text-gray-500 mt-2">
                    No reservation started yet !
                  </p>
                  <Button className="m-5">
                    <Link to="/">Click here to search for a hotel</Link>
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>

        <Toaster />
      </div>
      <div
        className="p-28 flex flex-col justify-center items-center gap-20"
        ref={reservationssRef}
      >
        <h1 className="scroll-m-20 text-4xl font-extrabold tracking-tight lg:text-5xl">
          List of my reservations
        </h1>
        <div className="w-full">
          <Table>
            <TableCaption>A list of your recent reservations.</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[100px]">Status</TableHead>
                <TableHead>Hotel</TableHead>
                <TableHead>Member</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Date de reservation</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead className="text-right">Creation Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reservations.map((res: any, idx: any) => {
                return (
                  <TableRow key={idx}>
                    <TableCell className="font-medium">
                      <Badge>{res.reservation_status}</Badge>
                    </TableCell>
                    <TableCell>{res.hotel.name}</TableCell>
                    <TableCell>{res.name_user}</TableCell>
                    <TableCell>{res.email}</TableCell>
                    <TableCell>{res.date_reservation}</TableCell>
                    <TableCell className="text-right">{res.Total} DT</TableCell>
                    <TableCell className="text-right">
                      {res.created_at}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>
    </>
  );
}

export default Reservations;
