import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { registerApi } from "@/services/login";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Toaster } from "@/components/ui/toaster";
export default function SignUp() {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const navigate = useNavigate();
  const SignUp = async () => {
    try {
      if (!email || !password) {
        toast({
          variant: "destructive",
          title: "Sign Up failed.",
          description: "Email and password are required.",
        });
        return; // Exit early if validation fails
      }

      if (password != confirmPassword) {
        toast({
          variant: "destructive",
          title: "Sign Up failed.",
          description: "Please check your confirmation password .",
        });
        return; // Exit early if validation fails
      }

      // Call the login API function with email and password
      const message = await registerApi(email, password);
      // Check if the token is valid before proceeding
      if (message) {
        toast({
          title: message,
        });
        setTimeout(() => {
          navigate("/login"); // Navigate to the home page or desired route
        }, 1500);
      } else {
        toast({
          variant: "destructive",
          title: "Sign Up failed.",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Sign Up failed.",
      });
    }
  };
  return (
    <div className="flex justify-center items-center h-screen w-full">
      <Card className="mx-auto max-w-sm">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold">SignUp</CardTitle>
          <CardDescription>
            Enter your email and password to create an account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="m@example.com"
                required
                value={email} // Bind email state
                onChange={(e) => setEmail(e.target.value)} // Update email state
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                required
                value={password} // Bind password state
                onChange={(e) => setPassword(e.target.value)} // Update password state
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Confirm Password</Label>
              <Input
                id="password"
                type="password"
                required
                value={confirmPassword} // Bind password state
                onChange={(e) => setConfirmPassword(e.target.value)} // Update password state
              />
            </div>
            <Button type="submit" className="w-full" onClick={SignUp}>
              Sign Up
            </Button>
          </div>
        </CardContent>
      </Card>
      <Toaster />
    </div>
  );
}
