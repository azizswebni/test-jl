import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/hooks/use-toast";
import {
  getReservationsApi,
  updateReservationApi,
} from "@/services/reservations";
import { useEffect, useState } from "react";
import { useSessionStorage } from "usehooks-ts";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useNavigate } from "react-router-dom";

function Admin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [authAdmin, setAuthAdmin] = useSessionStorage("MXuxL@D24FYb85", false);
  const { toast } = useToast();
  const admin_username = import.meta.env.VITE_APP_ADMIN_USERNAME;
  const admin_password = import.meta.env.VITE_APP_ADMIN_PASS;
  const [reservations, setReservations] = useState<any>([]);
  const [open, setOpen] = useState(false);
  const [updateReservationData, setUpdateReservationData] = useState<any>({});
  const navigate = useNavigate();
  useEffect(() => {
    const getReservations = async () => {
      const result = await getReservationsApi("", null);
      setReservations(result || []);
    };
    getReservations();
  }, []);

  const updateReservation = async () => {
    try {
      const response = await updateReservationApi(updateReservationData);
      setOpen(false);
      toast({
        title:response,
      })
      if (response) {
        setTimeout(() => {
          navigate(0);
        }, 1100);
      }
    } catch (err) {
      console.log(err);
    }
  };

  const loginAdmin = () => {
    if (admin_username != username || admin_password != password) {
      toast({
        title: "Wrong !",
        description: "Please verify your credentiels",
        variant: "destructive",
      });
      return;
    }
    setAuthAdmin(true);
  };
  return (
    <div className="min-h-screen">
      {!authAdmin && (
        <div className="flex justify-center items-center h-screen w-full">
          <Card className="mx-auto max-w-sm">
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold">Login</CardTitle>
              <CardDescription>
                Enter your username and password to login as admin
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Username</Label>
                  <Input
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                <Button type="submit" className="w-full" onClick={loginAdmin}>
                  Login
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      {authAdmin && (
        <div className="h-screen w-screen flex flex-col justify-center items-center p-10 gap-10">
          <div>
            <h1 className="scroll-m-20 text-4xl font-extrabold text-center tracking-tight lg:text-5xl">
              List of my reservations
            </h1>
          </div>
          <div className="w-full">
            <Table>
              <TableCaption>A list of recent reservations.</TableCaption>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[100px]">Status</TableHead>
                  <TableHead>Hotel</TableHead>
                  <TableHead>Member</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead className="text-right">Creation Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reservations.map((res: any, idx: any) => {
                  return (
                    <TableRow key={idx}>
                      <TableCell className="font-medium">
                        <Select
                          onValueChange={(e) => {
                            setUpdateReservationData({
                              id: res._id,
                              reservation_status: e,
                            });
                            setOpen(true);
                          }}
                          value={res.reservation_status}
                        >
                          <SelectTrigger className="w-[180px]">
                            <SelectValue placeholder={res.reservation_status} />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Approuved">Approuved</SelectItem>
                            <SelectItem value="Pending">Pending</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>{res.hotel.name}</TableCell>
                      <TableCell>{res.name_user}</TableCell>
                      <TableCell>{res.email}</TableCell>
                      <TableCell className="text-right">
                        {res.Total} DT
                      </TableCell>
                      <TableCell className="text-right">
                        {res.created_at}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
      <AlertDialog open={open}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Alert confirmation</AlertDialogTitle>
            <AlertDialogDescription>
              Are you absolutely sure to update this reservation status ?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setOpen(false)}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction onClick={updateReservation}>
              Continue
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Toaster />
    </div>
  );
}

export default Admin;
