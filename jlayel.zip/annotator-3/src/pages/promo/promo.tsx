import HotelCards from "@/components/hotels/hotels";
import { promo_hotels } from "@/data/promo_hotels";
import { useNavigate } from "react-router-dom";

function Promo() {
  const navigate = useNavigate()
  return (
    <HotelCards
      hotels={promo_hotels}
      add_reservation={() => {
        window.scrollTo({
          top: 0,
          left: 0,
          behavior: "smooth",
        });
        navigate("/login");
      }}
      title="Exclusive Hotel Promotions"
      currency="DT"
    />
  );
}

export default Promo;
