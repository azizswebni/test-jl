import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

interface reservationState {
  reservation_data: any;
  set_reservation_data: (reservation_data: any) => void;
  clear_reservation_data: () => void;
}

export const useReservationStore = create<reservationState>()(
  persist(
    (set) => ({
      reservation_data: null,
      set_reservation_data: (reservation_data: any) =>
        set({ reservation_data }),
      clear_reservation_data: () => set({ reservation_data: null }), // Optional clear function
    }),
    {
      name: "reservation-storage", // Key in sessionStorage
      storage: createJSONStorage(() => sessionStorage), // Use sessionStorage for persistence
    }
  )
);
